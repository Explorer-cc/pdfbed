By default, the MagicMouseTrails.ini will be created in the folder %APPDATA%/MagicMouseTrails

For portable use, please create or copy in MagicMouseTrails working directory the MagicMouseTrails.ini.

Or run an portable_install!

Program Arguments (Command Line)
-?uninstall
-?install
-?portable_install


Rename:
MagicMouseTrails.exe 
MagicMouseTrails_Install.exe 
MagicMouseTrails_Portable_Install.exe

 